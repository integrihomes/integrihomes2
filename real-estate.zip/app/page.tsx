import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Search, MapPin, ArrowRight, Phone, Mail, Clock } from "lucide-react"
import Link from "next/link"
import { PropertyCard } from "@/components/property-card"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { FeaturedProperty } from "@/components/featured-property"

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-gradient-to-b from-white to-gray-100">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                    Find Your Dream Home Today
                  </h1>
                  <p className="max-w-[600px] text-gray-500 md:text-xl">
                    Discover thousands of properties for sale and rent across the country. Your perfect home is just a
                    few clicks away.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="#properties">
                    <Button size="lg" className="gap-1.5">
                      Browse Properties
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/contact">
                    <Button size="lg" variant="outline">
                      Contact an Agent
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="bg-white p-6 shadow-lg rounded-xl">
                <div className="space-y-4">
                  <h2 className="text-xl font-bold">Find Your Perfect Property</h2>
                  <div className="grid gap-4">
                    <div className="grid gap-2">
                      <label htmlFor="location" className="text-sm font-medium leading-none">
                        Location
                      </label>
                      <div className="relative">
                        <MapPin className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                        <Input id="location" placeholder="City, neighborhood, or address" className="pl-8" />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <label htmlFor="property-type" className="text-sm font-medium leading-none">
                          Property Type
                        </label>
                        <Select>
                          <SelectTrigger id="property-type">
                            <SelectValue placeholder="Any" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="any">Any</SelectItem>
                            <SelectItem value="house">House</SelectItem>
                            <SelectItem value="apartment">Apartment</SelectItem>
                            <SelectItem value="condo">Condo</SelectItem>
                            <SelectItem value="townhouse">Townhouse</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid gap-2">
                        <label htmlFor="status" className="text-sm font-medium leading-none">
                          Status
                        </label>
                        <Select>
                          <SelectTrigger id="status">
                            <SelectValue placeholder="For Sale" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="for-sale">For Sale</SelectItem>
                            <SelectItem value="for-rent">For Rent</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <div className="flex items-center justify-between">
                        <label htmlFor="price-range" className="text-sm font-medium leading-none">
                          Price Range
                        </label>
                        <span className="text-sm text-gray-500">$100k - $1.5M</span>
                      </div>
                      <Slider defaultValue={[100, 1500]} min={0} max={3000} step={10} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <label htmlFor="bedrooms" className="text-sm font-medium leading-none">
                          Bedrooms
                        </label>
                        <Select>
                          <SelectTrigger id="bedrooms">
                            <SelectValue placeholder="Any" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="any">Any</SelectItem>
                            <SelectItem value="1">1+</SelectItem>
                            <SelectItem value="2">2+</SelectItem>
                            <SelectItem value="3">3+</SelectItem>
                            <SelectItem value="4">4+</SelectItem>
                            <SelectItem value="5">5+</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid gap-2">
                        <label htmlFor="bathrooms" className="text-sm font-medium leading-none">
                          Bathrooms
                        </label>
                        <Select>
                          <SelectTrigger id="bathrooms">
                            <SelectValue placeholder="Any" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="any">Any</SelectItem>
                            <SelectItem value="1">1+</SelectItem>
                            <SelectItem value="2">2+</SelectItem>
                            <SelectItem value="3">3+</SelectItem>
                            <SelectItem value="4">4+</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <Button className="w-full gap-1.5">
                      <Search className="h-4 w-4" />
                      Search Properties
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="featured" className="w-full py-12 md:py-24 lg:py-32 bg-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-gray-100 px-3 py-1 text-sm">Featured</div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Featured Properties</h2>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Explore our handpicked selection of premium properties available right now.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12">
              <FeaturedProperty />
            </div>
          </div>
        </section>

        <section id="properties" className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Browse Properties</h2>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Find your perfect home from our extensive collection of properties.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 mt-8">
              <PropertyCard
                id="1"
                title="Modern Apartment in Downtown"
                price="$450,000"
                address="123 Main St, Downtown"
                beds={2}
                baths={2}
                sqft={1200}
                type="Apartment"
                image="/placeholder.svg?height=400&width=600"
              />
              <PropertyCard
                id="2"
                title="Spacious Family Home"
                price="$750,000"
                address="456 Oak Ave, Suburbia"
                beds={4}
                baths={3}
                sqft={2500}
                type="House"
                image="/placeholder.svg?height=400&width=600"
              />
              <PropertyCard
                id="3"
                title="Luxury Condo with Ocean View"
                price="$1,200,000"
                address="789 Beach Blvd, Oceanside"
                beds={3}
                baths={2}
                sqft={1800}
                type="Condo"
                image="/placeholder.svg?height=400&width=600"
              />
              <PropertyCard
                id="4"
                title="Cozy Townhouse Near Park"
                price="$550,000"
                address="101 Park Lane, Greenville"
                beds={3}
                baths={2.5}
                sqft={1600}
                type="Townhouse"
                image="/placeholder.svg?height=400&width=600"
              />
              <PropertyCard
                id="5"
                title="Renovated Historic Home"
                price="$850,000"
                address="202 Heritage Dr, Old Town"
                beds={4}
                baths={3}
                sqft={2800}
                type="House"
                image="/placeholder.svg?height=400&width=600"
              />
              <PropertyCard
                id="6"
                title="Modern Studio Apartment"
                price="$320,000"
                address="303 Urban St, City Center"
                beds={1}
                baths={1}
                sqft={650}
                type="Apartment"
                image="/placeholder.svg?height=400&width=600"
              />
              <PropertyCard
                id="7"
                title="Waterfront Property"
                price="$1,500,000"
                address="404 Lake View Rd, Lakeside"
                beds={5}
                baths={4}
                sqft={3200}
                type="House"
                image="/placeholder.svg?height=400&width=600"
              />
              <PropertyCard
                id="8"
                title="Mountain Retreat Cabin"
                price="$650,000"
                address="505 Mountain Trail, Highland"
                beds={3}
                baths={2}
                sqft={1800}
                type="Cabin"
                image="/placeholder.svg?height=400&width=600"
              />
            </div>
            <div className="flex justify-center mt-10">
              <Button size="lg" variant="outline" className="gap-1.5">
                Load More Properties
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>

        <section id="cta" className="w-full py-12 md:py-24 lg:py-32 bg-gray-900 text-white">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">
                  Ready to Find Your Dream Home?
                </h2>
                <p className="max-w-[600px] text-gray-300 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Our expert agents are ready to help you navigate the real estate market and find the perfect property
                  for your needs.
                </p>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/contact">
                    <Button size="lg" className="bg-white text-gray-900 hover:bg-gray-100">
                      Contact an Agent
                    </Button>
                  </Link>
                  <Link href="/properties">
                    <Button size="lg" variant="outline" className="border-white text-white hover:bg-gray-800">
                      Browse All Properties
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="flex flex-col gap-4">
                <div className="flex items-center gap-4 rounded-lg bg-gray-800 p-4">
                  <Phone className="h-6 w-6 text-gray-300" />
                  <div>
                    <h3 className="font-medium">Call Us</h3>
                    <p className="text-gray-300">(555) 123-4567</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 rounded-lg bg-gray-800 p-4">
                  <Mail className="h-6 w-6 text-gray-300" />
                  <div>
                    <h3 className="font-medium">Email Us</h3>
                    <p className="text-gray-300">info@realestate.com</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 rounded-lg bg-gray-800 p-4">
                  <Clock className="h-6 w-6 text-gray-300" />
                  <div>
                    <h3 className="font-medium">Office Hours</h3>
                    <p className="text-gray-300">Mon-Fri: 9AM-6PM, Sat: 10AM-4PM</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}
