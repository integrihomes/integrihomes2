import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"
import { Expand } from "lucide-react"
import Image from "next/image"

export function PropertyGallery() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <Dialog>
        <DialogTrigger asChild>
          <div className="relative md:col-span-2 md:row-span-2 cursor-pointer group">
            <Image
              src="/placeholder.svg?height=600&width=800"
              alt="Property main view"
              width={800}
              height={600}
              className="rounded-lg object-cover w-full h-full aspect-square md:aspect-auto"
            />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors rounded-lg flex items-center justify-center">
              <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100">
                <Expand className="h-6 w-6 text-white" />
                <span className="sr-only">View full size</span>
              </Button>
            </div>
          </div>
        </DialogTrigger>
        <DialogContent className="max-w-4xl">
          <Image
            src="/placeholder.svg?height=800&width=1200"
            alt="Property main view"
            width={1200}
            height={800}
            className="rounded-lg object-cover w-full"
          />
        </DialogContent>
      </Dialog>

      {[1, 2, 3, 4].map((index) => (
        <Dialog key={index}>
          <DialogTrigger asChild>
            <div className="relative cursor-pointer group">
              <Image
                src={`/placeholder.svg?height=300&width=400&text=Image ${index}`}
                alt={`Property view ${index}`}
                width={400}
                height={300}
                className="rounded-lg object-cover w-full h-full aspect-square"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors rounded-lg flex items-center justify-center">
                <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100">
                  <Expand className="h-5 w-5 text-white" />
                  <span className="sr-only">View full size</span>
                </Button>
              </div>
            </div>
          </DialogTrigger>
          <DialogContent className="max-w-4xl">
            <Image
              src={`/placeholder.svg?height=800&width=1200&text=Image ${index}`}
              alt={`Property view ${index}`}
              width={1200}
              height={800}
              className="rounded-lg object-cover w-full"
            />
          </DialogContent>
        </Dialog>
      ))}
    </div>
  )
}
