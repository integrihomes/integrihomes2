import { Home, Facebook, Twitter, Instagram, Linkedin } from "lucide-react"
import Link from "next/link"

export function SiteFooter() {
  return (
    <footer className="w-full border-t bg-background">
      <div className="container px-4 py-12 md:px-6 md:py-16 lg:py-20">
        <div className="grid gap-8 sm:grid-cols-2 md:grid-cols-4">
          <div>
            <Link href="/" className="flex items-center gap-2 font-bold text-xl mb-4">
              <Home className="h-5 w-5" />
              <span>RealEstate</span>
            </Link>
            <p className="text-sm text-gray-500 mb-4">
              Your trusted partner in finding the perfect property. We make real estate simple and stress-free.
            </p>
            <div className="flex gap-4">
              <Link href="#" className="text-gray-500 hover:text-gray-900">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="text-gray-500 hover:text-gray-900">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link href="#" className="text-gray-500 hover:text-gray-900">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="#" className="text-gray-500 hover:text-gray-900">
                <Linkedin className="h-5 w-5" />
                <span className="sr-only">LinkedIn</span>
              </Link>
            </div>
          </div>
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <nav className="grid gap-3 text-sm">
              <Link href="/" className="text-gray-500 hover:text-gray-900">
                Home
              </Link>
              <Link href="/properties" className="text-gray-500 hover:text-gray-900">
                Properties
              </Link>
              <Link href="/agents" className="text-gray-500 hover:text-gray-900">
                Agents
              </Link>
              <Link href="/about" className="text-gray-500 hover:text-gray-900">
                About Us
              </Link>
              <Link href="/contact" className="text-gray-500 hover:text-gray-900">
                Contact
              </Link>
            </nav>
          </div>
          <div>
            <h3 className="font-semibold mb-4">Property Types</h3>
            <nav className="grid gap-3 text-sm">
              <Link href="#" className="text-gray-500 hover:text-gray-900">
                Houses
              </Link>
              <Link href="#" className="text-gray-500 hover:text-gray-900">
                Apartments
              </Link>
              <Link href="#" className="text-gray-500 hover:text-gray-900">
                Condos
              </Link>
              <Link href="#" className="text-gray-500 hover:text-gray-900">
                Townhouses
              </Link>
              <Link href="#" className="text-gray-500 hover:text-gray-900">
                Land
              </Link>
            </nav>
          </div>
          <div>
            <h3 className="font-semibold mb-4">Resources</h3>
            <nav className="grid gap-3 text-sm">
              <Link href="#" className="text-gray-500 hover:text-gray-900">
                Buying Guide
              </Link>
              <Link href="#" className="text-gray-500 hover:text-gray-900">
                Selling Guide
              </Link>
              <Link href="#" className="text-gray-500 hover:text-gray-900">
                Mortgage Calculator
              </Link>
              <Link href="#" className="text-gray-500 hover:text-gray-900">
                Market Trends
              </Link>
              <Link href="#" className="text-gray-500 hover:text-gray-900">
                FAQ
              </Link>
            </nav>
          </div>
        </div>
        <div className="mt-12 border-t pt-8 text-center text-sm text-gray-500">
          <p>&copy; {new Date().getFullYear()} RealEstate. All rights reserved.</p>
          <div className="mt-2 flex justify-center gap-4">
            <Link href="#" className="hover:underline">
              Privacy Policy
            </Link>
            <Link href="#" className="hover:underline">
              Terms of Service
            </Link>
            <Link href="#" className="hover:underline">
              Cookie Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
