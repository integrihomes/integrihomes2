import { Button } from "@/components/ui/button"
import { Bed, Bath, SquareIcon as SquareFoot, ArrowRight } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export function FeaturedProperty() {
  return (
    <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
      <Image
        src="/placeholder.svg?height=600&width=800"
        alt="Luxury Home"
        width={800}
        height={600}
        className="rounded-lg object-cover w-full aspect-[4/3]"
      />
      <div className="space-y-4">
        <div className="inline-block rounded-full bg-gray-100 px-3 py-1 text-sm font-medium">Featured</div>
        <h3 className="text-2xl font-bold">Luxury Waterfront Villa</h3>
        <p className="text-xl font-bold">$1,250,000</p>
        <p className="text-gray-500">
          This stunning waterfront villa offers breathtaking ocean views and luxurious living spaces. The property
          features an open floor plan with high ceilings, floor-to-ceiling windows, and premium finishes throughout.
        </p>
        <div className="flex gap-6 text-gray-500">
          <div className="flex items-center gap-1">
            <Bed className="h-5 w-5" />
            <span>4 Beds</span>
          </div>
          <div className="flex items-center gap-1">
            <Bath className="h-5 w-5" />
            <span>3.5 Baths</span>
          </div>
          <div className="flex items-center gap-1">
            <SquareFoot className="h-5 w-5" />
            <span>3,200 sq ft</span>
          </div>
        </div>
        <Link href="/properties/featured">
          <Button className="gap-1.5">
            View Property
            <ArrowRight className="h-4 w-4" />
          </Button>
        </Link>
      </div>
    </div>
  )
}
